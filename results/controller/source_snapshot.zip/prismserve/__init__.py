"""PrismServe: a course research prototype, not a production serving engine."""

__version__ = "0.4.0"
