"""Lazy imports keep analytical experiments independent of the PyTorch runtime."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import importlib.util
import json
from pathlib import Path
import platform
import sys


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="prismserve", description="PrismServe research prototype")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Show Python, dependencies and actual hardware")
    profile = commands.add_parser("profile", help="Measure bounded host/device/link microbenchmarks")
    profile.add_argument("--output", type=Path, default=Path("results/local_profile.json"))
    sim = commands.add_parser("simulate", help="Run analytical policy comparisons")
    sim.add_argument("--config", type=Path, default=Path("configs/experiment.json"))
    sim.add_argument("--output", type=Path, default=Path("results/simulation"))
    sim.add_argument("--trace", type=Path, help="Normalized request CSV; config must contain one seed")
    train = commands.add_parser("train", help="Train a tiny byte decoder on the included authored corpus")
    train.add_argument("--output", type=Path, default=Path("results/tiny"))
    train.add_argument("--steps", type=int, default=100)
    train.add_argument("--seed", type=int, default=7)
    quality = commands.add_parser("quality", help="Measure held-out tiny-model NLL/PPL and logit KL")
    quality.add_argument("--checkpoint", type=Path)
    quality.add_argument("--output", type=Path, default=Path("results/quality"))
    demo_cmd = commands.add_parser("demo", help="Train and run real reversible INT4 and CPU KV demo")
    demo_cmd.add_argument("--output", type=Path, default=Path("results/demo"))
    demo_cmd.add_argument("--steps", type=int, default=60)
    adapt = commands.add_parser("adapt", help="Run real decoder with the common controller under declared quotas")
    adapt.add_argument("--checkpoint", type=Path)
    adapt.add_argument("--output", type=Path, default=Path("results/adaptive"))
    adapt.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    serve = commands.add_parser("serve", help="Start local tiny-model completion API")
    serve.add_argument("--checkpoint", type=Path)
    serve.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    report = commands.add_parser("report", help="Regenerate tables/figures from a completed simulation")
    report.add_argument("--results", type=Path, default=Path("results/simulation"))
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            from .telemetry import detect_hardware
            result = {"python": sys.version, "platform": platform.platform(),
                      "dependencies": {n: importlib.util.find_spec(n) is not None for n in
                                       ["numpy", "psutil", "torch", "fastapi", "uvicorn", "matplotlib"]},
                      "hardware": asdict(detect_hardware())}
        elif args.command == "profile":
            from .telemetry import profile_hardware
            result = asdict(profile_hardware(args.output))
        elif args.command == "simulate":
            from .experiments import run_experiments
            result = run_experiments(args.config, args.output, args.trace)
        elif args.command == "report":
            from .reporting import build_report
            result = {"report": str(build_report(args.results).resolve())}
        elif args.command == "adapt":
            from .runtime import adaptive_demo
            result = adaptive_demo(args.output, args.checkpoint, args.device)
        elif args.command == "serve":
            import uvicorn
            from .service import create_app
            uvicorn.run(create_app(args.checkpoint, args.device), host=args.host, port=args.port)
            return
        else:
            from .torch_backend import demo, run_quality, train_tiny
            if args.command == "train":
                result = train_tiny(args.output, args.steps, args.seed)
            elif args.command == "quality":
                result = run_quality(args.output, args.checkpoint)
            else:
                result = demo(args.output, args.steps)
        print(json.dumps(result, indent=2, allow_nan=False))
    except (ValueError, FileNotFoundError, ImportError) as exc:
        parser.exit(2, f"prismserve: {exc}\n")
